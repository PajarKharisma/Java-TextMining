package Metode;

import java.util.LinkedList;
import File.Doc;
import File.DocSorting;
import Process.Tokenizing;
import SubProcess.OpenFile;
import java.util.ArrayList;

public class C45MethodTesting extends TFIDFCalculator {
    
    private int limit = 10;
    private LinkedList<String> listName = new LinkedList<>();
    private String numeric[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    private LinkedList<Check> listChecks = new LinkedList<>();
    
    public void getResult() {
        deleteDir();
        getWord();
        for(int i=0; i<doc.length; i++){
            String docName = doc[i].getName();
            docName = docName.replaceAll(".txt", "");
            docName = docName.replaceAll(" ", "");
            for (String j : numeric) {
                docName = docName.replaceAll(j, "");
            }
            
            DocSorting[] docSorting = new DocSorting[doc[i].getList().size()];
            for (int j = 0; j < docSorting.length; j++) {
                docSorting[j] = new DocSorting();
            }

            for (int j = 0; j < doc[i].getList().size(); j++) {
                double tfidf = tfIdf(doc[i].getList(), listDocs, doc[i].getList().get(j));
                docSorting[j].setTerm(doc[i].getList().get(j));
                docSorting[j].setValue(tfidf);
            }
            
            for (int x = 0; x < docSorting.length; x++) {
                for (int y = x + 1; y < docSorting.length; y++) {
                    if (docSorting[x].getTerm().compareTo(docSorting[y].getTerm()) > 0) {
                        DocSorting tmpDoc = new DocSorting();
                        tmpDoc = docSorting[x];
                        docSorting[x] = docSorting[y];
                        docSorting[y] = tmpDoc;
                    }
                }
            }
            
            for (int j = 0; j < docSorting.length - 1; j++) {
                int index = j;
                for (int k = j + 1; k < docSorting.length; k++) {
                    if (docSorting[k].getValue() < docSorting[index].getValue()) { //sorting
                        index = k;
                    }
                }

                DocSorting tmpDoc = new DocSorting();
                tmpDoc = docSorting[index];
                docSorting[index] = docSorting[j];
                docSorting[j] = tmpDoc;
            }
            
            LinkedList<DocSorting> list = new LinkedList<DocSorting>();
            
            for (int j = 0; j < docSorting.length - 1; j++) {
                if (!docSorting[j].getTerm().equalsIgnoreCase(docSorting[j + 1].getTerm())) {
                    list.add(docSorting[j]);
                }
            }
            
            Check check = new Check();
            check.setData(list, docName);
            listChecks.add(check);
            
            /*
            System.out.println("Name Doc : "+docName);
            for(DocSorting ds:list)
                System.out.println("Term : "+ds.getTerm() + " || "+ds.getValue());
            
            System.out.println("==================================================\n\n");
            */
        }
        
        LinkedList<LinkedList<DocSorting>> listAllIndex = new LinkedList<>();
        LinkedList<DocSorting> listTerms = new LinkedList<>();
        /*
        for(int i=0; i<listChecks.size()-1; i++){
            if(listChecks.get(i).getDocName().equalsIgnoreCase(listChecks.get(i+1).getDocName())){
                listTerms.addAll(listChecks.get(i).getTerms());
            }else{
                listTerms.addAll(listChecks.get(i).getTerms());
                listAllIndex.add(listTerms);
                listTerms.clear();
            }
        }
        */
        
        System.out.println("Size of List : "+listAllIndex.size());
        ///*
        for(LinkedList<DocSorting> ll:listAllIndex){
            System.out.println("\n===============================================\n");
            for(DocSorting ds:ll){
                System.out.println("Term : "+ds.getTerm()+" || Value : "+ds.getValue());
            }
        }
        //*/
        /*
        for(Check cc:listChecks){
            System.out.println("Doc Name : "+cc.getDocName());
            for(DocSorting ds:cc.getTerms()){
                System.out.println("Term : "+ds.getTerm()+ " || Value : " +ds.getValue());
            }
            System.out.println();
        }
        //*/
    }
}

class Check{
    private LinkedList<DocSorting> terms;
    private String docName;
    
    public void setData(LinkedList<DocSorting> terms, String docName){
        this.terms = terms;
        this.docName = docName;
    }
    
    public LinkedList<DocSorting> getTerms(){
        return this.terms;
    }
    
    public String getDocName(){
        return this.docName;
    }
}