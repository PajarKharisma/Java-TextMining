package Metode;

import java.util.LinkedList;

import File.DocSorting;

public class KnnMethod extends TFIDFCalculator {

    public void getResult() {
        deleteDir();
        getWord();
        for (int i = 0; i < doc.length; i++) {
            //System.out.println("Nama Dokument : " + doc[i].getName());
            DocSorting[] docSorting = new DocSorting[doc[i].getList().size()];
            for (int j = 0; j < docSorting.length; j++) {
                docSorting[j] = new DocSorting();
            }

            for (int j = 0; j < doc[i].getList().size(); j++) {
                docSorting[j].setTerm(doc[i].getList().get(j));
                docSorting[j].setValue(0);
            }

            for (int x = 0; x < docSorting.length; x++) {
                for (int y = x + 1; y < docSorting.length; y++) {
                    if (docSorting[x].getTerm().compareTo(docSorting[y].getTerm()) > 0) {
                        DocSorting tmpDoc = new DocSorting();
                        tmpDoc = docSorting[x];
                        docSorting[x] = docSorting[y];
                        docSorting[y] = tmpDoc;
                    }
                }
            }

            LinkedList<DocSorting> list = new LinkedList<DocSorting>();

            for (int j = 0; j < docSorting.length - 1; j++) {
                if (!docSorting[j].getTerm().equalsIgnoreCase(docSorting[j + 1].getTerm())) {
                    list.add(docSorting[j]);
                }
            }
            
            String outputText = "";
            String outTfIdf = "";
            for (DocSorting k : list) {
                outputText += k.getTerm() + " ";
                outTfIdf += k.getTerm() + " || " + k.getValue() + "\n";
            }

            writeTxt.writeFile(outputText, "output\\TfIdfOutput\\", doc[i].getName());
            writeTxt.writeFile(outTfIdf, "log\\TFIDF\\", doc[i].getName());
        }
    }
}
