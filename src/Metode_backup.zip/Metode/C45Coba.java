package Metode;

import File.Doc;
import File.DocSorting;
import Process.Tokenizing;
import SubProcess.OpenFile;
import java.util.LinkedList;

public class C45Coba extends TFIDFCalculator {

    private String numeric[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    private LinkedList<String> list;

    public void getResult() {
        list = new LinkedList<String>();
        deleteDir();
        getDoc();
        openFile = new OpenFile();
        tokenizing = new Tokenizing();
        listDocs = new LinkedList<>();
        String[] names = new String[file.length];

        for (int i = 0; i < file.length; i++) {
            names[i] = file[i].getName();
            names[i] = names[i].replaceAll(".txt", "");
            names[i] = names[i].replaceAll(" ", "");
            for (String j : numeric) {
                names[i] = names[i].replaceAll(j, "");
            }
        }

        for (int i = 0; i < file.length; i++) {
            if (i < file.length - 1) {
                if (!names[i].equalsIgnoreCase(names[i + 1])) {
                    list.add(names[i]);
                }
            } else {
                list.add(names[i]);
            }
        }

        doc = new Doc[list.size()];

        String[] input = new String[list.size()];

        for (int i = 0; i < input.length; i++) {
            input[i] = "";
        }

        int iterasi = 0;
        for (int i = 0; i < file.length; i++) {
            if (file[i].getName().startsWith(list.get(iterasi))) {
                input[iterasi] += openFile.getFile(file[i]);
            } else {
                iterasi++;
                input[iterasi] += openFile.getFile(file[i]);
            }
        }

        for (int i = 0; i < doc.length; i++) {
            doc[i] = new Doc();
            doc[i].setName(list.get(i));
            doc[i].setList(tokenizing.getTokenizingResult(input[i]));
        }

        for (int i = 0; i < doc.length; i++) {
            DocSorting[] docSorting = new DocSorting[doc[i].getList().size()];
            for (int j = 0; j < docSorting.length; j++) {
                docSorting[j] = new DocSorting();
            }

            for (int j = 0; j < doc[i].getList().size(); j++) {
                double tfidf = tfIdf(doc[i].getList(), listDocs, doc[i].getList().get(j));
                docSorting[j].setTerm(doc[i].getList().get(j));
                docSorting[j].setValue(tfidf);
            }

            for (int x = 0; x < docSorting.length; x++) {
                for (int y = x + 1; y < docSorting.length; y++) {
                    if (docSorting[x].getTerm().compareTo(docSorting[y].getTerm()) > 0) {
                        DocSorting tmpDoc = new DocSorting();
                        tmpDoc = docSorting[x];
                        docSorting[x] = docSorting[y];
                        docSorting[y] = tmpDoc;
                    }
                }
            }

            for (int j = 0; j < docSorting.length - 1; j++) {
                int index = j;
                for (int k = j + 1; k < docSorting.length; k++) {
                    if (docSorting[k].getValue() > docSorting[index].getValue()) {
                        index = k;
                    }
                }

                DocSorting tmpDoc = new DocSorting();
                tmpDoc = docSorting[index];
                docSorting[index] = docSorting[j];
                docSorting[j] = tmpDoc;
            }
            
            for(DocSorting ds:docSorting)
                System.out.println("Term : "+ds.getTerm() + " || Value : "+ds.getValue());

            LinkedList<DocSorting> list = new LinkedList<DocSorting>();

            for (int j = 0; j < docSorting.length - 1; j++) {
                if (!docSorting[j].getTerm().equalsIgnoreCase(docSorting[j + 1].getTerm())) {
                    list.add(docSorting[j]);
                }
            }

            String outputText = "";
            for (int k = 0; k < 10; k++) {
                outputText += list.get(k).getTerm() + " ";
            }

            writeTxt.writeFile(outputText, "output\\TfIdfOutput\\", doc[i].getName());
        }
    }
}
