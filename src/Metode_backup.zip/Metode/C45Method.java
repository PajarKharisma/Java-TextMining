package Metode;

import java.util.LinkedList;
import File.DocSorting;

public class C45Method extends TFIDFCalculator {

    private LinkedList<DocSorting> listAll = new LinkedList<>();
    private String numeric[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    private LinkedList<String> listName = new LinkedList<>();
    private int limit = 20;

    public void getResult() {
        deleteDir();
        getWord();
        for (int i = 0; i < doc.length; i++) {
            //System.out.println("Nama Dokument : " + doc[i].getName());
            listName.add(doc[i].getName());
            DocSorting[] docSorting = new DocSorting[doc[i].getList().size()];
            for (int j = 0; j < docSorting.length; j++) {
                docSorting[j] = new DocSorting();
            }

            for (int j = 0; j < doc[i].getList().size(); j++) {
                double tfidf = tfIdf(doc[i].getList(), listDocs, doc[i].getList().get(j));
                docSorting[j].setTerm(doc[i].getList().get(j));
                docSorting[j].setValue(tfidf);
                //System.out.println("Word : " + doc[i].getList().get(j) + "    ||     value : " + tfidf);
            }

            for (int x = 0; x < docSorting.length; x++) {
                for (int y = x + 1; y < docSorting.length; y++) {
                    if (docSorting[x].getTerm().compareTo(docSorting[y].getTerm()) > 0) {
                        DocSorting tmpDoc = new DocSorting();
                        tmpDoc = docSorting[x];
                        docSorting[x] = docSorting[y];
                        docSorting[y] = tmpDoc;
                    }
                }
            }

            for (int j = 0; j < docSorting.length - 1; j++) {
                int index = j;
                for (int k = j + 1; k < docSorting.length; k++) {
                    if (docSorting[k].getValue() < docSorting[index].getValue()) {//proses sorting
                        index = k;
                    }
                }

                DocSorting tmpDoc = new DocSorting();
                tmpDoc = docSorting[index];
                docSorting[index] = docSorting[j];
                docSorting[j] = tmpDoc;
            }

            LinkedList<DocSorting> list = new LinkedList<DocSorting>();

            for (int j = 0; j < docSorting.length - 1; j++) {
                if (!docSorting[j].getTerm().equalsIgnoreCase(docSorting[j + 1].getTerm())) {
                    list.add(docSorting[j]);
                }
            }

            for (DocSorting ds : list) {
                listAll.add(ds);
            }
        }

        LinkedList<String> filteredName = new LinkedList<>();
        LinkedList<String> finalName = new LinkedList<>();

        for (String name : listName) {
            name = name.replaceAll(".txt", "");
            name = name.replaceAll(" ", "");
            for (String j : numeric) {
                name = name.replaceAll(j, "");
            }
            filteredName.add(name);
        }

        for (int i = 0; i < filteredName.size(); i++) {
            if (i < filteredName.size() - 1) {
                if (!filteredName.get(i).equalsIgnoreCase(filteredName.get(i + 1))) {
                    finalName.add(filteredName.get(i));
                }
            } else {
                finalName.add(filteredName.get(i));
            }
        }

        String nameText = "";
        for (String fn : finalName) {
            nameText += fn + " ";
        }

        DocSorting[] docSorting = new DocSorting[listAll.size()];

        for (int i = 0; i < listAll.size(); i++) {
            docSorting[i] = new DocSorting();
            docSorting[i] = listAll.get(i);
        }

        for (int j = 0; j < docSorting.length - 1; j++) {
            int index = j;
            for (int k = j + 1; k < docSorting.length; k++) {
                if (docSorting[k].getValue() < docSorting[index].getValue()) {//proses sorting
                    index = k;
                }
            }
            
            DocSorting tmpDoc = new DocSorting();
            tmpDoc = docSorting[index];
            docSorting[index] = docSorting[j];
            docSorting[j] = tmpDoc;
        }

        LinkedList<DocSorting> list = new LinkedList<>();
        /*
        for (int j = 0; j < docSorting.length - 1; j++) {
            if (!docSorting[j].getTerm().equalsIgnoreCase(docSorting[j + 1].getTerm())) {
                list.add(docSorting[j]);
            }
        }
        */
        for(int j=0; j<docSorting.length-1; j++){
            int result = 0;
            for(int k=0; k<list.size(); k++){
                if(docSorting[j].getTerm().equalsIgnoreCase(list.get(k).getTerm())){
                    result++;
                }
            }
            if(result<1)
                list.add(docSorting[j]);
        }
        
        /*
        for (DocSorting ds : list) {
            System.out.println("Term : " + ds.getTerm() + " ||  Value : " + ds.getValue());
        }
        */

        String outputText = "";
        if (docSorting.length > limit - 1) {
            for (int k = 0; k < limit; k++) {
                outputText += list.get(k).getTerm() + " ";
            }
        }

        writeTxt.writeFile(outputText, "output\\C45\\", "C45Output.txt");
        writeTxt.writeFile(nameText, "output\\C45\\", "DocumentName.txt");
        listName.clear();
    }
}