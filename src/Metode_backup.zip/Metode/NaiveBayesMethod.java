package Metode;

import java.util.LinkedList;

import File.DocSorting;

public class NaiveBayesMethod extends TFIDFCalculator {

    public void getResult() {
        deleteDir();
        getWord();
        for (int i = 0; i < doc.length; i++) {
            //System.out.println("Nama Dokument : " + doc[i].getName());
            DocSorting[] docSorting = new DocSorting[doc[i].getList().size()];
            for (int j = 0; j < docSorting.length; j++) {
                docSorting[j] = new DocSorting();
            }

            for (int j = 0; j < doc[i].getList().size(); j++) {
                double tfidf = tfIdf(doc[i].getList(), listDocs, doc[i].getList().get(j));
                docSorting[j].setTerm(doc[i].getList().get(j));
                docSorting[j].setValue(tfidf);
                //System.out.println("Word : " + doc[i].getList().get(j) + "    ||     value : " + tfidf);
            }

            for (int x = 0; x < docSorting.length; x++) {
                for (int y = x + 1; y < docSorting.length; y++) {
                    if (docSorting[x].getTerm().compareTo(docSorting[y].getTerm()) > 0) {
                        DocSorting tmpDoc = new DocSorting();
                        tmpDoc = docSorting[x];
                        docSorting[x] = docSorting[y];
                        docSorting[y] = tmpDoc;
                    }
                }
            }

            for (int j = 0; j < docSorting.length - 1; j++) {
                int index = j;
                for (int k = j + 1; k < docSorting.length; k++) {
                    if (docSorting[k].getValue() < docSorting[index].getValue()) { //sorting
                        index = k;
                    }
                }

                DocSorting tmpDoc = new DocSorting();
                tmpDoc = docSorting[index];
                docSorting[index] = docSorting[j];
                docSorting[j] = tmpDoc;
            }

            LinkedList<DocSorting> list = new LinkedList<DocSorting>();

            for (int j = 0; j < docSorting.length - 1; j++) {
                if (!docSorting[j].getTerm().equalsIgnoreCase(docSorting[j + 1].getTerm())) {
                    list.add(docSorting[j]);
                }
            }

            for(DocSorting ds:list)
                System.out.println("Term : "+ds.getTerm() + "|| Value : "+ds.getValue());
            
            String outputText = "";
            //System.out.println("Size : "+list.size());
            String outTfIdf = "";
            for(DocSorting ds : list){
                outTfIdf += ds.getTerm() + " || " + ds.getValue() + "\n";
            }
            System.out.println("\n\n==================================================\n\n");
            
            if(list.size() > 9){
                for (int k = 0; k < 10; k++) {
                    outputText += list.get(k).getTerm() + " ";
                }
            }
            
            writeTxt.writeFile(outputText, "output\\TfIdfOutput\\", doc[i].getName());
            writeTxt.writeFile(outTfIdf, "log\\TFIDF\\", doc[i].getName());

            /*for(int k=0; k<10; k++){
             System.out.println("Nama : "+list.get(k).getTerm()+"   ||    Value : "+list.get(k).getValue());
             }
    		
             System.out.println("===============================================\n\n");*/
        }
    }
}
